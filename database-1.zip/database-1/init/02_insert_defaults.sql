USE `sapp20250721`;

-- Seed default users
INSERT INTO `tblusers`(`full_name`, `email_address`, `hashed_password`, `roles`)
VALUES
('Admin', 'admin01@gmail.com', '$2b$12$Kb36EMkihS5pRYJaahHsu.DN.cTGU3tINmOWIZmzekzlt4h4SOpxu', 'admin'),
('User Me', 'user01@gmail.com', '$2b$12$KHFA62iMeAOIYDGCqRY5LuohfOsqvQ4NMGdbMjS4fx.sWEMoJVi9u', 'user');

-- Seed signatories
INSERT INTO `tblsignatories` (`full_name`, `title`, `layout_order`) VALUES
('Ana G. Cruz', 'Parish Secretary', 1),
('Rev. Fr. Santos M. Reyes', 'Co-Pastor', 2),
('Rev. Fr. Michael C. Vincent', 'Parish Priest', 3);
